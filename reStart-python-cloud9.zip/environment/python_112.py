myMixedTypeList [45, 290578, 1.02, True, "My dog is on the bed.", "4"]
#for loop:
for item in myMixedTypeList:
    print("{} is data type of {}".format(item,type(item)))