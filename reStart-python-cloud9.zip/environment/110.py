a="Hellow World"
print(a)
print(type(a))
print(str(a)+str(type(a)))
firststring="Water"
secondstring="Falls"
thirdstring=firststring=secondstring
print(thirdstring)
name=input("enter your name: ")
print(name)
place=input("enter you place: ")
year=input("enter your year: ")
print("{} is live in {} since {}".format(name,place,year))
