#exercise1:list of index
myfruitlist=["mango","banana","lemon","fig","kiwi"]
print(myfruitlist)
print(type(myfruitlist))
print(myfruitlist[0])
print(myfruitlist[1])
print(myfruitlist[2])
print(myfruitlist[3])
print(myfruitlist[4])

myfruitlist[4]="berry"
print(myfruitlist)
#exercise2:indexing in tuples
myfinaltuple=("mango","banana","lemon","fig","kiwi")
print(myfinaltuple)
print(myfinaltuple[0])
print(myfinaltuple[1])
print(myfinaltuple[2])
print(myfinaltuple[3])
print(myfinaltuple[4])
#exercise3:dict
favfruitdict={"tami":"mango","dinesh":"banana","ram":"lemon","kalai":"fig","nantha":"kiwi"}
print(favfruitdict)
print(type(favfruitdict))
print(favfruitdict["tami"])
print(favfruitdict["dinesh"])
print(favfruitdict["ram"])
print(favfruitdict["kalai"])
print(favfruitdict["nantha"])