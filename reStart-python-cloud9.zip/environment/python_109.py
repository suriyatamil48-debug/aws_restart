#int:
a=10
print(a)
print(type)
print(str(a)+"is the data type of"+str(type(a)))
#float:
b=8.5
print(b)
print(type(b))
print(str(b)+"is the data type of"+str(type(b)))
#complex:
x=5j
print(x)
print(type(x))
print(str(x)+"data type of"+str(type(x)))
#boolean:
m=True
print(m)
print(type(m))
print(str(m)+"data type of"+str(type(m)))
n=False
print(n)
print(type(n))
print(str(n)+"data type of"+str(type(n)))